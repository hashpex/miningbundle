#!/bin/sh
while [ 1 ]; do
./cpuminer -a cpupower -o stratum+tcp://hashpex.com:3032 -u WALLET_ADDRESS
done
