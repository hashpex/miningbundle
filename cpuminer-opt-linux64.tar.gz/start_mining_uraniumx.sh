#!/bin/sh
while [ 1 ]; do
./cpuminer -a yespowerurx -o stratum+tcp://hashpex.com:4055 -u WALLET_NUMBER
done
