#!/bin/sh
while [ 1 ]; do
./cpuminer -a yescryptr16 -o stratum+tcp://hashpex.com:4113 -u WALLET_NUMBER
done
