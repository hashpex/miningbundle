#!/bin/sh
while [ 1 ]; do
./cpuminer -a yespowerlitb -o stratum+tcp://hashpex.com:3331 -u WALLET_ADDRESS
done
